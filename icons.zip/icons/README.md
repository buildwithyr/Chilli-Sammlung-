# Homescreen-Icons einbauen

Zwei Varianten, je 512 / 192 / 180 / 32 px:

- `2c/` — Schote auf Glut-Schwarz
- `2e/` — Glut-Fläche mit Initialen „OR"

## Einbauen

Dateien aus dem gewählten Ordner nach `assets/icons/` kopieren und umbenennen:

```
icon-512.png  →  assets/icons/icon-512.png
icon-192.png  →  assets/icons/icon-192.png
icon-180.png  →  assets/icons/icon-180.png
icon-32.png   →  assets/icons/icon-32.png
```

In `index.html` die SVG-Zeile entfernen (die neuen Icons sind PNG):

```html
<!-- diese Zeile löschen -->
<link rel="icon" href="assets/icons/icon.svg" type="image/svg+xml">
```

In `manifest.json` zusätzlich:

```json
"theme_color": "#14100e",
"background_color": "#14100e"
```

## Hinweis zu iOS

Der Homescreen von iOS rundet das Icon selbst ab. Die PNGs sind bereits mit
runden Ecken exportiert — falls das Icon auf dem iPhone einen dunklen Rand
zeigt, sag Bescheid, dann exportiere ich eine Version mit vollflächigem
Hintergrund ohne eigene Rundung (das ist die technisch sauberere Variante
für `apple-touch-icon`).

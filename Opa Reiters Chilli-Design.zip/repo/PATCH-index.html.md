# Ember-Theme einbauen — 3 Änderungen in `index.html`

`style.css` komplett durch die neue Datei ersetzen. Danach in `index.html`:

### 1. Schriften laden (im `<head>`, vor `<link rel="stylesheet" href="style.css">`)

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

### 2. Theme-Farbe der PWA anpassen

```html
<!-- vorher -->
<meta name="theme-color" content="#c1440e">
<!-- nachher -->
<meta name="theme-color" content="#14100e">
```

Gleiches in `manifest.json`: `theme_color` auf `#14100e`, `background_color` auf `#14100e`.

### 3. Titel zweizeilig auszeichnen (damit die zweite Zeile orange wird)

```html
<!-- vorher -->
<h1>Opa Reiters Chili Sammlung</h1>
<!-- nachher -->
<h1>Opa Reiters <span class="brand-accent">Chili Sammlung</span></h1>
```

Der Text bleibt identisch — nur die zweite Zeile bekommt Glut-Orange.

---

## Was ohne JS-Änderung schon funktioniert

- Schärfe-Skala im Formular: die zehn 🌶️-Buttons werden per CSS zu einem Glut-Balken (Emoji auf `font-size: 0`, Button wird zum Segment). Kein `app.js`-Eingriff.
- Foto-Platzhalter: Kamera-Emoji raus, gestreifte Fläche mit `KEIN FOTO` per `::after`.
- Status-Badges bekommen automatisch einen Farbpunkt statt eines Chips.
- Pull-to-Refresh-Emoji wird zum rotierenden Ring.

## Optional (braucht kleine `app.js`-Änderungen)

1. **Heat-Balken auf der Karte** — 5 Segmente je nach Schärfegrad, wie in Variante 1b. Dazu muss in `renderCard()` (~Zeile 1226) ein `<div class="card-heat">` mit `data-level` ausgegeben werden; CSS liefere ich mit.
2. **Status-Farben pro Phase** (Aussaat grau, Blüte grün, Ernte orange) — braucht eine Status-Klasse am Badge, z. B. `badge-status status-bluete`.
3. **Chart.js-Farben** in der Statistik: Balkenfarbe `#ff6a2b`, Gitter `#33261f`, Schrift `#9d8577` — steht in `app.js` bei der Chart-Konfiguration.

Sag Bescheid, dann schreibe ich diese drei Patches auch.
